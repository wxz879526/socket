#include "stdafx.h"
#include "MY.h"

CMyWinApp theApp;

IMPLEMENT_DYNCREATE(CMyFrameWnd, CFrameWnd)
IMPLEMENT_DYNCREATE(CMyDoc, CDocument)
IMPLEMENT_DYNCREATE(CMyView, CView)

int main()
{
	CWinApp *pApp = AfxGetApp();
	pApp->InitApplication();
	pApp->InitInstance();
	pApp->Run();

	CRuntimeClass *pClassRef;
	CObject *pObj;

	while (1)
	{
		if ((pClassRef = CRuntimeClass::Load()) == nullptr)
			continue;

		pObj = pClassRef->CreateObject();
		if (pObj)
			pObj->SayHello();
	}

	return 0;
}

BOOL CMyWinApp::InitInstance()
{
	cout << "CMyWinApp InitInstance \n";
	m_pMainWnd = new CMyFrameWnd;
	return TRUE;
}

void PrintAllClasses()
{
	CRuntimeClass* pClass;
	for (pClass = CRuntimeClass::pFirstClass; pClass != nullptr; pClass = pClass->m_pNextClass)
	{
		cout << pClass->m_lpszClassName << endl;
	}
}
