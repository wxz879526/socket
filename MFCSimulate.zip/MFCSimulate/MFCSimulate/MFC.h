#pragma once

#include <iostream>

using namespace std;

#define BOOL int
#define TRUE 1
#define FALSE 0

#define LPCSTR LPSTR
typedef char* LPSTR;

#define UINT int
#define PASCAL __stdcall

#define TRACE1 printf

class CObject;
struct CRuntimeClass
{
	LPCSTR m_lpszClassName;
	int m_nObjectSize;
	UINT m_wSchema;
	CObject* (PASCAL* m_pfnCreateObject)();
	CRuntimeClass* m_pBaseClass;

	CObject* CreateObject();
	static CRuntimeClass* PASCAL Load();

	static CRuntimeClass* pFirstClass;
	CRuntimeClass *m_pNextClass;
};

#define DECLARE_DYNAMIC(class_name) \
public: \
	static CRuntimeClass class##class_name; \
	virtual CRuntimeClass* GetRuntimeClass() const;

#define RUNTIME_CLASS(class_name) \
(&class_name::class##class_name)

#define DECLARE_DYNCREATE(class_name) \
	DECLARE_DYNAMIC(class_name) \
	static CObject* PASCAL CreateObject();

struct AFX_CLASSINIT
{
	AFX_CLASSINIT(CRuntimeClass* pNewClass)
	{
		pNewClass->m_pNextClass = CRuntimeClass::pFirstClass;
		CRuntimeClass::pFirstClass = pNewClass;
	}
};

#define _IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, wSchema, pfnNew) \
	static char _lpsz##class_name[] = #class_name; \
	CRuntimeClass class_name::class##class_name = {\
	_lpsz##class_name, sizeof(class_name), wSchema, pfnNew, RUNTIME_CLASS(base_class_name), NULL}; \
	static AFX_CLASSINIT _init_##class_name(&class_name::class##class_name); \
	CRuntimeClass* class_name::GetRuntimeClass() const \
	{ return &class_name::class##class_name;}

#define IMPLEMENT_DYNAMIC(class_name, base_class_name) \
	_IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, 0xFFFF, NULL)

#define IMPLEMENT_DYNCREATE(class_name, base_class_name) \
	CObject* PASCAL class_name::CreateObject() \
	{return new class_name;} \
	_IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, 0xFFFFF, class_name::CreateObject)

class CObject
{
	DECLARE_DYNAMIC(CObject)

public:
	CObject()
	{
		cout << "CObject Constructor \n";
	}

	~CObject()
	{
		cout << "CObject Destructor \n";
	}

	BOOL IsKindOf(const CRuntimeClass* pClass);

	virtual void SayHello() { cout << "Hello CObject" << endl; }
};

class CCmdTarget : public CObject
{
	DECLARE_DYNAMIC(CCmdTarget)

public:
	CCmdTarget()
	{
		cout << "CCmdTarget Constructor \n";
	}

	~CCmdTarget()
	{
		cout << "CCmdTarget Destructor \n";
	}
};

class CWinThread : public CCmdTarget
{
	DECLARE_DYNAMIC(CWinThread)

public:
	CWinThread()
	{
		cout << "CWinThread Constructor \n";
	}

	~CWinThread()
	{
		cout << "CWinThread Destructor \n";
	}

	virtual BOOL InitInstance()
	{
		cout << "CWinThread InitInstance \n";
		return TRUE;
	}

	virtual int Run()
	{
		cout << "CWinThread Run \n";
		return 1;
	}
};

class CWnd;

class CWinApp : public CWinThread
{
	DECLARE_DYNAMIC(CWinApp)

public:
	CWinApp *m_pCurrentWinApp;
	CWnd *m_pMainWnd;

public:
	CWinApp()
	{
		m_pCurrentWinApp = this;
		cout << "CWinApp Constructor \n";
	}

	~CWinApp()
	{
		cout << "CWinApp Destructor \n";
	}

	virtual BOOL InitApplication()
	{
		cout << "CWinApp InitApplication \n";
		return TRUE;
	}

	virtual BOOL InitInstance() override
	{
		cout << "CWinApp InitInstance \n";
		return TRUE;
	}

	virtual int Run() override
	{
		cout << "CWinApp Run \n";
		return CWinThread::Run();
	}
};

class CDocument : public CCmdTarget
{
	DECLARE_DYNAMIC(CDocument)

public:
	CDocument()
	{
		cout << "CDocument Constructor \n";
	}

	~CDocument()
	{
		cout << "CDocument Destructor \n";
	}
};

class CWnd : public CCmdTarget
{
	DECLARE_DYNCREATE(CWnd)

public:
	CWnd()
	{
		cout << "CWnd Constructor \n";
	}

	~CWnd()
	{
		cout << "CWnd Destructor \n";
	}

	virtual BOOL Create();
	BOOL CreateEx();
	virtual BOOL PreCreateWindow();

	void SayHello() override
	{
		cout << "Hello CWnd" << endl;
	}
};

class CFrameWnd : public CWnd
{
	DECLARE_DYNCREATE(CFrameWnd)

public:
	CFrameWnd()
	{
		cout << "CFrameWnd Constructor \n";
	}

	~CFrameWnd()
	{
		cout << "CFrameWnd Destructor \n";
	}

	virtual BOOL Create() override;

	virtual BOOL PreCreateWindow() override;

	void SayHello() override
	{
		cout << "Hello CWnd" << endl;
	}
};

class CView : public CWnd
{
	DECLARE_DYNAMIC(CView)

public:
	CView()
	{
		cout << "CView Constructor \n";
	}

	~CView()
	{
		cout << "CView Destructor \n";
	}
};

CWinApp* AfxGetApp();
