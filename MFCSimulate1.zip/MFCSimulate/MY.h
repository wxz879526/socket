#pragma once
#include "MFC.h"

class CMyWinApp : public CWinApp
{
public:
	CMyWinApp()
	{
		cout << "CMyWinApp Constructor \n";
	}

	~CMyWinApp()
	{
		cout << "CMyWinApp Destructor \n";
	}

	virtual BOOL InitInstance() override;

	DECLARE_MESSAGE_MAP()
};

class CMyFrameWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CMyFrameWnd)

public:
	CMyFrameWnd()
	{
		cout << "CMyFrameWnd Constructor \n";
		Create();
	}

	~CMyFrameWnd()
	{
		cout << "CMyFrameWnd Destructor \n";
	}

	void SayHello() override
	{
		cout << "CMyFrameWnd SayHello \n";
	}

	DECLARE_MESSAGE_MAP()
};

class CMyDoc : public CDocument
{
	DECLARE_DYNCREATE(CMyDoc)

public:
	CMyDoc()
	{
		cout << "CMyDoc Constructor \n";
	}

	~CMyDoc()
	{
		cout << "CMyDoc Destructor \n";
	}

	void SayHello() override
	{
		cout << "CMyDoc SayHello \n";
	}

	DECLARE_MESSAGE_MAP()
};

class CMyView : public CView
{
	DECLARE_DYNCREATE(CMyView)

public:
	CMyView()
	{
		cout << "CMyView Constructor \n";
	}

	~CMyView()
	{
		cout << "CMyView Destructor \n";
	}

	void SayHello() override
	{
		cout << "CMyView SayHello \n";
	}

	DECLARE_MESSAGE_MAP()
};

void PrintAllClasses();
