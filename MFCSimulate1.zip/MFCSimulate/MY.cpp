#include "stdafx.h"
#include "MY.h"

CMyWinApp theApp;

IMPLEMENT_DYNCREATE(CMyFrameWnd, CFrameWnd)
IMPLEMENT_DYNCREATE(CMyDoc, CDocument)
IMPLEMENT_DYNCREATE(CMyView, CView)

BEGIN_MESSAGE_MAP(CMyWinApp, CWinApp)
	ON_COMMAND(CMyWinAppid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMyFrameWnd, CFrameWnd)
	ON_COMMAND(CMyFrameWndid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMyDoc, CDocument)
	ON_COMMAND(CMyDocid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CMyView, CView)
	ON_COMMAND(CMyViewid, 0)
END_MESSAGE_MAP()

void printlpEntries(AFX_MSGMAP_ENTRY *lpEntry)
{
	struct {
		int classid;
		char *classname;
	} classInfo[] = {
		{CCmdTargetid, "CCmdTarget"},
		{CWinThreadid, "CWinThread"},
		{CWinAppid, "CWinApp"},
		{CWndid, "CWnd"},
		{CFrameWndid, "CFrameWnd"},
		{CMyFrameWndid, "CMyFrameWnd"},
		{CViewid, "CView"},
		{CMyViewid, "CMyView"},
		{CDocumentid, "CDocument"},
		{CMyDocid, "CMyDoc"},
		{0, "   "}
	};

	for (int i = 0; i < classInfo[i].classid != 0; ++i)
	{
		if (classInfo[i].classid == lpEntry->nID)
		{
			cout << lpEntry->nID << "  ";
			cout << classInfo[i].classname << endl;
			break;
		}
	}
}

void MsgMapPrinting(AFX_MSGMAP *pMessageMap)
{
	for (; pMessageMap != nullptr; pMessageMap = pMessageMap->pBaseMessageMap)
	{
		AFX_MSGMAP_ENTRY *lpEntry = pMessageMap->pEntries;
		printlpEntries(lpEntry);
	}
}

int main()
{
	CWinApp *pApp = AfxGetApp();
	pApp->InitApplication();
	pApp->InitInstance();
	pApp->Run();

	/*CRuntimeClass *pClassRef;
	CObject *pObj;

	while (1)
	{
		if ((pClassRef = CRuntimeClass::Load()) == nullptr)
			continue;

		pObj = pClassRef->CreateObject();
		if (pObj)
			pObj->SayHello();
	}*/

	CMyDoc *pMyDoc = new CMyDoc;
	CMyView *pMyView = new CMyView;
	CFrameWnd *pMyFrame = (CFrameWnd*)pApp->m_pMainWnd;

	AFX_MSGMAP *pMessageMap = pMyView->GetMessageMap();
	cout << endl << " CMyView MessageMap: " << endl;
	MsgMapPrinting(pMessageMap);

	return 0;
}

BOOL CMyWinApp::InitInstance()
{
	cout << "CMyWinApp InitInstance \n";
	m_pMainWnd = new CMyFrameWnd;
	return TRUE;
}

void PrintAllClasses()
{
	CRuntimeClass* pClass;
	for (pClass = CRuntimeClass::pFirstClass; pClass != nullptr; pClass = pClass->m_pNextClass)
	{
		cout << pClass->m_lpszClassName << endl;
	}
}
