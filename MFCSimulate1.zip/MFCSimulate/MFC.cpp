#include "stdafx.h"
#include "MY.h"

extern CMyWinApp theApp;

CRuntimeClass* CRuntimeClass::pFirstClass = nullptr;

static char szObject[] = "COject";
struct CRuntimeClass CObject::classCObject = {
	szObject, sizeof(CObject), 0xFFFF, NULL, NULL
};

static AFX_CLASSINIT _init_CObject(&CObject::classCObject);

CObject* CRuntimeClass::CreateObject()
{
	if (m_pfnCreateObject == NULL)
	{
		TRACE1("Error: Trying to create object which is not DECLARE_DYNCREATE"
			" or DECLARE_SERIAL: %hs.\n", m_lpszClassName);
		return NULL;
	}

	CObject *pObject = NULL;
	pObject = (*m_pfnCreateObject)();
	return pObject;
}

CRuntimeClass* PASCAL CRuntimeClass::Load()
{
	char szClassName[64];
	CRuntimeClass *pClass;

	cout << "Enter a class name... ";
	cin >> szClassName;

	for (pClass = CRuntimeClass::pFirstClass; pClass != nullptr; pClass = pClass->m_pNextClass)
	{
		if (_stricmp(szClassName, pClass->m_lpszClassName) == 0)
		{
			return pClass;
		}
	}

	TRACE1("Error: Class not found: %s \n", szClassName);
	return NULL;
}

CRuntimeClass* CObject::GetRuntimeClass()const
{
	return &CObject::classCObject;
}

BOOL CObject::IsKindOf(const CRuntimeClass* pClass)
{
	CRuntimeClass *pClassThis = GetRuntimeClass();
	while (pClassThis)
	{
		if (pClassThis == pClass)
			return TRUE;

		pClassThis = pClassThis->m_pBaseClass;
	}

	return FALSE;
}

IMPLEMENT_DYNAMIC(CCmdTarget, CObject)
IMPLEMENT_DYNAMIC(CWinThread, CCmdTarget)
IMPLEMENT_DYNAMIC(CWinApp, CWinThread)
IMPLEMENT_DYNCREATE(CWnd, CCmdTarget)
IMPLEMENT_DYNCREATE(CFrameWnd, CWnd)
IMPLEMENT_DYNAMIC(CDocument, CCmdTarget)
IMPLEMENT_DYNAMIC(CView, CWnd)

CWinApp* AfxGetApp()
{
	return theApp.m_pCurrentWinApp;
}

BOOL CWnd::Create()
{
	cout << "CWnd Create \n";
	return TRUE;
}

BOOL CWnd::CreateEx()
{
	cout << "CWnd CreateEx \n";
	PreCreateWindow();
	return TRUE;
}

BOOL CWnd::PreCreateWindow()
{
	cout << "CWnd PreCreateWindow \n";
	return TRUE;
}

BOOL CFrameWnd::Create()
{
	cout << "CFrameWnd Create \n";
	CreateEx();
	return TRUE;
}

BOOL CFrameWnd::PreCreateWindow()
{
	cout << "CFrameWnd PreCreateWindow \n";
	return TRUE;
}

AFX_MSGMAP* CCmdTarget::GetMessageMap()const
{
	return &CCmdTarget::messageMap;
}

AFX_MSGMAP CCmdTarget::messageMap = { NULL,
&CCmdTarget::_messageEntries[0] };

AFX_MSGMAP_ENTRY CCmdTarget::_messageEntries[] = 
{
	{0, 0, CCmdTargetid, 0, AfxSig_end, 0}
};

BEGIN_MESSAGE_MAP(CWnd, CCmdTarget)
	ON_COMMAND(CWndid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CFrameWnd, CWnd)
	ON_COMMAND(CFrameWndid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CDocument, CCmdTarget)
	ON_COMMAND(CDocumentid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CView, CWnd)
	ON_COMMAND(CViewid, 0)
END_MESSAGE_MAP()

BEGIN_MESSAGE_MAP(CWinApp, CCmdTarget)
	ON_COMMAND(CWinAppid, 0)
END_MESSAGE_MAP()